from django.apps import AppConfig


class TimerConfig(AppConfig):
    name = 'timer'
