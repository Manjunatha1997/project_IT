from django.shortcuts import render
from login.models import *
from datetime import datetime, timedelta, date

# Create your views here.
def home(request):
    user = request.user
    print(user)
    profile_info = Profile.objects.get(user=str(request.user))
    name = profile_info.name
    profile = profile_info.profile.url

    all_users = Profile.objects.all()
    today = date.today()
    start_date = today - timedelta(days=3)
    end_date = today + timedelta(days=3)
    start_day = start_date.day
    end_day = end_date.day
    day = datetime.now().day
    month = datetime.now().month

    birthday_users = []
    for user in all_users:
        bday = user.dob
        birth_day = bday.day
        birth_month = bday.month
        if month == birth_month:
            if birth_day >= start_day and birth_day <= end_day:
                print(bday, ":", birth_day, ":", birth_month)
                birthday_users.append(user)

    return render(request, "home/home.html", {'name': name, 'profile': profile, 'users': birthday_users})
