from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

from login.forms import *
from login.models import *

from datetime import datetime, timedelta, date

# Create your views here.
def login(request):
    return render(request, "login/login.html")

@login_required(login_url="/auth/login/")
def update_profile(request):
    form = ProfileForm()
    if request.method == "POST":
        form = ProfileForm(request.POST)
        if form.is_valid():
            profile_info = form.save(commit=False)
            profile_info.user = str(request.user)
            print("Trying to save..")
            profile_info.save()
            return redirect("/home/")
        else:
            print("Form is not Valid")
    else:
        print("Not Post..")
    return render(request, "login/profile.html", {'form': form})

@login_required(login_url="/auth/login/")
def show_profile(request):
    profile_info = Profile.objects.get(user=str(request.user))
    print(profile_info.__dict__)
    print("*******************")

    name = profile_info.name
    profile = profile_info.profile.url
    manager_profile = Profile.objects.get(user=str(profile_info.manager))
    manager = manager_profile.name
    manager_id = profile_info.manager
    return render(request, "login/show_profile.html", {'profile_info': profile_info, 'name': name, 'profile': profile, 'manager': manager, 'manager_id': manager_id})



@login_required(login_url="/auth/login/")
def search_profile(request):
    form = SearchForm()
    if 'user' in request.GET or 'name' in request.GET or 'manager' in request.GET:
        users = []

        if request.GET.get('user'):
            profile_info = Profile.objects.filter(user=str(request.GET.get('user')))
            users.extend(profile_info)

        if request.GET.get('name'):
            profile_info = Profile.objects.filter(name__contains=str(request.GET.get('name')))
            users.extend(profile_info)

        if request.GET.get('manager'):
            profile_info = Profile.objects.filter(manager__contains=str(request.GET.get('manager')))
            users.extend(profile_info)
        print("***", users, "***")
        return render(request, "login/show.html", {'users': users})
    return render(request, "login/search.html", {'form': form})


def show_employee(request, id):
    user = Profile.objects.get(user=str(id))
    return render(request, "login/show_employee.html", {'user': user})

from django.http import HttpResponse

def get_birthday_employees(request):
    all_users = Profile.objects.all()
    today = date.today()
    start_date = today - timedelta(days=3)
    end_date = today + timedelta(days=3)
    start_day = start_date.day
    end_day = end_date.day
    day = datetime.now().day
    month = datetime.now().month
    print(day, month, "->", start_day, end_day)
    birthday_users = []
    for user in all_users:
        bday = user.dob
        birth_day = bday.day
        birth_month = bday.month
        if month == birth_month:
            if birth_day >= start_day and birth_day <= end_day:
                print(bday, ":", birth_day, ":", birth_month)
                birthday_users.append(user)

    return HttpResponse("Done")