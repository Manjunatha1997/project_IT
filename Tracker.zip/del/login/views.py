from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

from login.forms import *
from login.models import *


# Create your views here.
def login(request):
    return render(request, "login/login.html")

@login_required(login_url="/auth/login/")
def update_profile(request):
    form = ProfileForm()
    if request.method == "POST":
        form = ProfileForm(request.POST)
        if form.is_valid():
            profile_info = form.save(commit=False)
            profile_info.user = str(request.user)
            print("Trying to save..")
            profile_info.save()
            return redirect("/home/")
        else:
            print("Form is not Valid")
    else:
        print("Not Post..")
    return render(request, "login/profile.html", {'form': form})

@login_required(login_url="/auth/login/")
def show_profile(request):
    profile_info = Profile.objects.get(user=str(request.user))
    return render(request, "login/show_profile.html", {'profile': profile_info})
